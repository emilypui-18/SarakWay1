// this file was used for alerts.jsx if admin needs to see who to send alert

const express = require("express");
const router = express.Router();
const db = require("../db");

/* GET all guides */
router.get("/guides", (req, res) => {
  const query = `
    SELECT user_id, user_name
    FROM users
    WHERE role_id = 2
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "database error" });
    }

    res.json(results);
  });
});

module.exports = router;